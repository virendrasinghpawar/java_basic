package com.exception;

public class InvalidUserException extends Exception {
	
public InvalidUserException(){}
public InvalidUserException(String s)
{
	super(s) ;
}

}
